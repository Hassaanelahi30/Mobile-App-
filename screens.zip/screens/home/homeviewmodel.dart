import 'package:vaultchatapp/core/models/usermodel.dart';
import 'package:vaultchatapp/core/other/baseviewmodel.dart';
import 'package:vaultchatapp/core/services/databaservice.dart';

class Homeviewmodel extends BaseViewModel {
  final Databaservice _db;
  Usermodel? _currentUser;

  Usermodel? get currentUser => _currentUser;

  Homeviewmodel(this._db);


}
