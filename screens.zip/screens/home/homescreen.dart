import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:vaultchatapp/core/constants/colors.dart';
import 'package:vaultchatapp/core/extensions/widgetextension.dart';
import 'package:vaultchatapp/core/services/authservice.dart';
import 'package:vaultchatapp/core/constants/string.dart';
import 'package:vaultchatapp/core/services/databaservice.dart';
import 'package:vaultchatapp/ui/screens/home/homeviewmodel.dart';
import 'package:vaultchatapp/ui/screens/other/userprovider.dart';


class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});


  @override
  Widget build(BuildContext context) {
    final userprovider=Provider.of<Userprovider>(context);
    return ChangeNotifierProvider(
      create: (context) => Homeviewmodel(Databaservice()),
      child: Consumer<Homeviewmodel>(
        builder: (context, model, _) {
          return Scaffold(
            appBar: AppBar(
              title: Text("Home"),
              centerTitle: true,
            ),
            body: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Center(
                  child:userprovider.user==null?const CircularProgressIndicator():InkWell(
                    onTap: () async {
                      try {
                        await AuthService().logout();
                        context.showSnackbar("Logged out successfully");
                        Navigator.pushReplacementNamed(context, login);
                      } catch (error) {
                        context.showSnackbar("Logout failed: $error");
                      }
                    },
                    child: Text(
                      "Logout",
                      style: TextStyle(
                        fontSize: 16.0,
                        color:primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                Center(
                  child: Text(userprovider.user.toString()),
                )
              ],
            ),
          );
        },
      ),
    );
  }
}
