import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vaultchatapp/core/constants/string.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer(const Duration(seconds: 2), () {
      Navigator.pushReplacementNamed(context, wrapper);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

    @override
    Widget build(BuildContext context) {
      return Scaffold(
        body: Stack(
          children: [
            Image.asset(
              frame,
              height: 1.sh,
              width: 1.sw,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) => Container(
                color: Colors.grey,
                child: const Center(child: Text("Background failed to load")),
              ),
            ),
            Center(
              child: Image.asset(
                logo,
                height: 235.h,
                width: 235.w,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => const Icon(
                  Icons.image_not_supported,
                  size: 50,
                  color: Colors.red,
                ),
              ),
            ),
          ],
        ),
      );
    }
  }
