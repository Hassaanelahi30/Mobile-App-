import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vaultchatapp/core/constants/colors.dart';
import 'package:vaultchatapp/core/constants/string.dart';
import 'package:vaultchatapp/core/constants/styles.dart';
import 'package:vaultchatapp/core/enums/enums.dart';
import 'package:vaultchatapp/core/extensions/widgetextension.dart';
import 'package:vaultchatapp/core/services/authservice.dart';
import 'package:vaultchatapp/core/services/databaservice.dart';
import 'package:vaultchatapp/ui/screens/home/widgets/custombutton.dart';
import 'package:vaultchatapp/ui/screens/home/widgets/textfieldwidget.dart';
import 'package:provider/provider.dart';
import 'package:vaultchatapp/ui/screens/auth/signup/signupviewmodel.dart';



class SignupScreen extends StatelessWidget {
  const SignupScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => SignupViewModel(AuthService(),Databaservice()),
      child: Consumer<SignupViewModel>(
        builder: (context, model, _) {
          return Scaffold(
            body: SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 1.sw * 0.05, vertical: 20.h),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    30.verticalSpace,
                    Text("Create your Account", style: h),
                    10.verticalSpace,
                    Text("Please provide the details", style: body.copyWith(color: grey)),
                    30.verticalSpace,
                    Customtextfield(
                      onChanged: (value) => model.setName(value),
                      hinttext: "Enter Name",
                    ),
                    30.verticalSpace,
                    Customtextfield(
                      onChanged: (value) => model.setEmail(value),
                      hinttext: "Enter Email",
                    ),
                    30.verticalSpace,
                    Customtextfield(
                      onChanged: (value) => model.setPassword(value),
                      hinttext: "Enter Password",
                      obscureText: true,
                    ),
                    30.verticalSpace,
                    Customtextfield(
                      onChanged: (value) => model.setConfirmPassword(value),
                      hinttext: "Confirm Password",
                      obscureText: true,
                    ),
                    30.verticalSpace,
                    model.state == ViewState.loading
                        ? const CircularProgressIndicator()
                        : Custombutton(
                            onPressed: () async {
                              await model.signup();
                              if (model.errorMessage != null) {
                                context.showSnackbar(model.errorMessage!);
                              } else {
                                context.showSnackbar("Account created successfully");
                                //Navigator.pop(context);
                              }
                            },
                            text: "Sign Up",
                          ),
                    20.verticalSpace,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Already have an account?", style: body.copyWith(color: grey)),
                        InkWell(
                          onTap: () => Navigator.pushNamed(context, login),
                          child: Text(" Login", style: body.copyWith(fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}