import 'dart:developer';
import 'package:vaultchatapp/core/enums/enums.dart';
import 'package:vaultchatapp/core/models/usermodel.dart';
import 'package:vaultchatapp/core/other/baseviewmodel.dart';
import 'package:vaultchatapp/core/services/authservice.dart';
import 'package:vaultchatapp/core/services/databaservice.dart';

class SignupViewModel extends BaseViewModel {
  final AuthService _auth;
  final Databaservice _db;

  String _name = '';
  String _email = '';
  String _password = '';
  String _confirmPassword = '';
  String? _errorMessage;

  // Getter for error message
  String? get errorMessage => _errorMessage;

  // Constructor
  SignupViewModel(this._auth, this._db);

  // Setters for the fields
  void setName(String value) {
    _name = value.trim(); // Trim whitespace for cleaner data
    notifyListeners();
    log("Name: $_name");
  }

  void setEmail(String value) {
    _email = value.trim(); // Trim whitespace for cleaner data
    notifyListeners();
    log("Email: $_email");
  }

  void setPassword(String value) {
    _password = value;
    notifyListeners();
    log("Password: $_password");
  }

  void setConfirmPassword(String value) {
    _confirmPassword = value;
    notifyListeners();
    log("Confirm Password: $_confirmPassword");
  }

  // Signup method to register a new user
  Future<void> signup() async {
    if (_password.isEmpty || _confirmPassword.isEmpty || _name.isEmpty || _email.isEmpty) {
      _errorMessage = "All fields are required!";
      notifyListeners();
      return;
    }

    if (_password != _confirmPassword) {
      _errorMessage = "Passwords do not match!";
      notifyListeners();
      return;
    }

    try {
      setState(ViewState.loading);

      // Call the signup method of AuthService
      final res = await _auth.signup(email: _email, password: _password, name: _name);

      if (res != null) {
        // Create a user model and save it to Firestore
        Usermodel user = Usermodel(uid: res.uid, name: _name, email: _email);
        await _db.saveUser(user.toMap());
        log("Signup and save successful for user: ${user.uid}");
      }

      // On successful signup, set the state to success
      setState(ViewState.success);
      _errorMessage = null;
    } catch (e) {
      log("Error during signup: $e");
      setState(ViewState.error);
      _errorMessage = "Signup failed. Please try again.";
    }
  }
}
