import 'package:vaultchatapp/core/enums/enums.dart';
import 'package:vaultchatapp/core/other/baseviewmodel.dart';
import 'package:vaultchatapp/core/services/authservice.dart';
import 'dart:developer';

class LoginViewModel extends BaseViewModel {
  final AuthService _auth;
  LoginViewModel(this._auth);

  String _email = '';
  String _password = '';
  String? _errorMessage;

  // Getter for error message
  String? get errorMessage => _errorMessage;

  // Setter for email
  void setEmail(String value) {
    _email = value;
    notifyListeners();
    log("Email: $_email");
  }

  // Setter for password
  void setPassword(String value) {
    _password = value;
    notifyListeners();
    log("Password: $_password");
  }

  // Login method using the AuthService
  Future<void> login() async {
    if (_email.isEmpty || _password.isEmpty) {
      _errorMessage = "Email and password cannot be empty!";
      notifyListeners();
      return;
    }

    try {
      // Set state to loading while the login process is ongoing
      setState(ViewState.loading);

      // Call the login method of AuthService
      final user = await _auth.login(email: _email, password: _password);

      if (user != null) {
        // On successful login, set the state to success
        setState(ViewState.success);
        _errorMessage = null;
      } else {
        // If login failed
        _errorMessage = "Invalid email or password!";
        setState(ViewState.error);
        notifyListeners();
      }
    } catch (e) {
      // If an error occurs, log the error and set state to error
      log(e.toString());
      setState(ViewState.error);
      _errorMessage = e.toString();
      notifyListeners();
    }
  }
}
