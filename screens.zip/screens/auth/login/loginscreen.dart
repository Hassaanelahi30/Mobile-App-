import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:vaultchatapp/core/constants/colors.dart';
import 'package:vaultchatapp/core/constants/string.dart';
import 'package:vaultchatapp/core/constants/styles.dart';
import 'package:vaultchatapp/core/enums/enums.dart';
import 'package:vaultchatapp/core/extensions/widgetextension.dart';
import 'package:vaultchatapp/core/services/authservice.dart';
import 'package:vaultchatapp/ui/screens/auth/login/loginviewmodel.dart';
import 'package:vaultchatapp/ui/screens/home/widgets/custombutton.dart';
import 'package:vaultchatapp/ui/screens/home/widgets/textfieldwidget.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => LoginViewModel(AuthService()),
      child: Consumer<LoginViewModel>(
        builder: (context, model, _) {
          return Scaffold(
            body: SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 1.sw * 0.05, vertical: 20.h),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    30.verticalSpace,
                    Text("Login", style: h),
                    10.verticalSpace,
                    Text("Please login to your account", style: body.copyWith(color: grey)),
                    30.verticalSpace,
                    Customtextfield(
                      onChanged: (value) => model.setEmail(value.trim()),
                      hinttext: "Enter Email",
                    ),
                    30.verticalSpace,
                    Customtextfield(
                      onChanged: (value) => model.setPassword(value.trim()),
                      hinttext: "Enter Password",
                      obscureText: true,
                    ),
                    30.verticalSpace,
                    model.state == ViewState.loading
                        ? const CircularProgressIndicator()
                        : Custombutton(
                            onPressed: () async {
                              await model.login();
                              if (model.state == ViewState.success) {
                                context.showSnackbar("User logged in successfully");
                                Navigator.pushReplacementNamed(context, home);
                              } else if (model.errorMessage != null && model.errorMessage!.isNotEmpty) {
                                context.showSnackbar(model.errorMessage!);
                              }
                            },
                            text: "Login",
                          ),
                    20.verticalSpace,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Don't have an account?", style: body.copyWith(color: grey)),
                        InkWell(
                          onTap: () => Navigator.pushNamed(context, signup),
                          child: Text(" Sign Up", style: body.copyWith(fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

