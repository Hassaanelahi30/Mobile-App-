import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:vaultchatapp/ui/screens/auth/login/loginscreen.dart';
import 'package:vaultchatapp/ui/screens/bottomnavigation/bottomnavigation.dart';
import 'package:vaultchatapp/ui/screens/other/userprovider.dart';

class Wrapper extends StatelessWidget {
  const Wrapper({super.key});
  

  @override
  Widget build(BuildContext context) {
    final userprovider=Provider.of<Userprovider>(context,listen: false);
    return StreamBuilder(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        final user = snapshot.data;
        if (user == null) {
          return const LoginScreen();
        } else {
          userprovider.loadUser(user.uid);
          return  bottomnavigation();
        }
      },
    );
  }
}