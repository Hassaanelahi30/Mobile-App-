import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vaultchatapp/core/constants/colors.dart';
import 'package:vaultchatapp/core/constants/string.dart';
import 'package:vaultchatapp/core/constants/styles.dart';

class Customtextfield extends StatelessWidget {
  const Customtextfield({
    super.key,
    this.onChanged,
    this.hinttext,
    this.focusNode,
    this.obscureText = false, 
    this.isSearch=false
    // Default to false
  });

  final void Function(String)? onChanged;
  final String? hinttext;
  final FocusNode? focusNode;
  final bool obscureText;
  final bool isSearch;

  @override
  Widget build(BuildContext context) {
    return TextField(
      onChanged: onChanged,
      focusNode: focusNode,
      obscureText: obscureText, // Use the obscureText parameter
      decoration: InputDecoration(
        filled: true,
        fillColor: grey.withOpacity(0.2),
        hintText: hinttext,
        hintStyle: body.copyWith(color: grey),
        suffixIcon: isSearch?Container(padding: EdgeInsets.all(12),decoration: BoxDecoration(color:primary,borderRadius: BorderRadius.circular(20.r)),height: 60,width: 60,
        child: Image.asset(searchicon),):null,
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.circular(10.r),
        ),
      ),
    );
  }
}
